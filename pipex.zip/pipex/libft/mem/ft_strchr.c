/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 11:17:03 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/13 11:17:04 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"

char	*ft_strchr(const char *s, int c)
{
	int				i;
	unsigned char	ch;

	ch = (char)c;
	i = 0;
	while (s[i] != '\0')
	{
		if (s[i] == ch)
			return ((char *)s + i);
		i++;
	}
	if (s[i] == '\0' && s[i] == ch)
		return ((char *)s + i);
	return (NULL);
}
/*
int main() {
    const char *str = "Hello, world!";
    int character = '4'; // Character to search for

    char *result = ft_strchr(str, character);

    if (result != NULL) {
        printf("Found '%c' at position: %ld\n", character, result - str);
    } else {
        printf("Character '%c' not found\n", character);
    }

    return 0;
}
*/
