/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 11:12:27 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/13 11:14:36 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"

t_list	*ft_lstnew(void *content)
{
	t_list	*add;

	add = malloc(sizeof(t_list));
	if (add == NULL)
	{
		return (0);
	}
	add -> content = content;
	add -> next = NULL;
	return (add);
}
