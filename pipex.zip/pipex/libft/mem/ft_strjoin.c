/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 11:17:32 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/13 11:17:33 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	char	*d;
	size_t	len1;
	size_t	len2;

	if (!s1 && !s2)
		return (ft_strdup(""));
	if (s1 && !s2)
		return (ft_strdup(s1));
	if (!s1 && s2)
		return (ft_strdup(s2));
	len1 = ft_strlen(s1);
	len2 = ft_strlen(s2);
	d = malloc(sizeof(char) * (len1 + len2 + 1));
	if (!d)
		return (NULL);
	ft_strlcpy(d, s1, len1 + 1);
	ft_strlcat(d, s2, len1 + len2 + 1);
	return (d);
}
/*
int main(void) {
    char const *s1 = "Hello, ";
    char const *s2 = "world!";

    // Test ft_strjoin function
    char *result = ft_strjoin(s1, s2);

    // Print the result
    if (result != NULL) {
        printf("Concatenated string: %s\n", result);
        free(result); // Free allocated memory
    } else {
        printf("Error: Concatenated string is NULL\n");
    }

    return 0;
}
*/
