/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 11:11:00 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/13 11:11:04 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"

int	ft_isdigit(int c)
{
	return ('0' <= c && c <= '9');
}
/*
int main() {
    char test_char = '7'; // Change the character to test different cases

    if (ft_isdigit(test_char)) {
        printf("%c is a digit.\n", test_char);
    } else {
        printf("%c is not a digit.\n", test_char);
    }

    return 0;
}
*/
