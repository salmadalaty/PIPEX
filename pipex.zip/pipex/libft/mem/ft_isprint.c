/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isprint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 11:11:10 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/13 11:11:13 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"

int	ft_isprint(int c)
{
	return (c >= 32 && c <= 126);
}
/*
int main()
{
    char test_char = 'A';
    if (ft_isprint(test_char))
        printf("%c is a printable character.\n", test_char);
    else
        printf("%c is not a printable character.\n", test_char);

    return 0;
}
*/
