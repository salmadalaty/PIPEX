/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 11:15:54 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/13 11:15:59 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"

void	*ft_memset(void *s, int c, size_t n)
{
	size_t	i;
	char	*str;

	i = 0;
	str = (char *)s;
	while (i < n)
	{
		str[i] = c;
		i++;
	}
	return (s);
}
/*
int main() {
    char buffer[10]; // Create a buffer to hold characters

    // Use ft_memset to fill the buffer with 'A' (ASCII value 65)
    ft_memset(buffer, 'A', 10);

    // Print the content of the buffer
    printf("Buffer after memset: %s\n", buffer);

    return 0;
}
*/
