/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isascii.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 11:10:52 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/13 11:10:55 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"

int	ft_isascii(int c)
{
	return (c >= 0 && c <= 127);
}
/*
int main()
{
    char test_char = 'A';
    if (ft_isascii(test_char))
        printf("%c is an ASCII character.\n", test_char);
    else
        printf("%c is not an ASCII character.\n", test_char);

    return 0;
}
*/
