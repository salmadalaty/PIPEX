/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sdalaty <sdalaty@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/13 11:15:02 by sdalaty           #+#    #+#             */
/*   Updated: 2024/07/13 11:15:06 by sdalaty          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"

void	*ft_memchr(const void *s, int c, size_t n)
{
	size_t					i;
	char					ch;
	const unsigned char		*str;

	ch = c;
	str = s;
	i = 0;
	while (i < n)
	{
		if (*((unsigned char *)(str + i)) == (unsigned char)ch)
			return ((unsigned char *)str + i);
		i++;
	}
	return (NULL);
}
